package com;

public class RectangleArea {
	 public static void main(String[] args) 
     { 
           //Creating objects 
           Rectangle firstRect = new Rectangle(); 
           firstRect.setData(5,6); 
           int result = firstRect.area(); 
           System.out.println("Area of Rectangle = "+ result); 
     } 
}
